# Altamira Stripe Fulfillment

Webhook de Stripe para entrega automática del PDF 5M Scalping System PRO mediante Resend.

## Variables de entorno

- STRIPE_WEBHOOK_SECRET
- RESEND_API_KEY
- EMAIL_FROM
- PAYMENT_LINK_ID
- DOWNLOAD_URL

## Endpoint

`/api/stripe-webhook`
